package hr.fer.rovkp.lab4.zad2;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.NoSuchElementException;

/**
 * Created by Igor Farszky on 5.6.2017..
 */
public class Zad2 {

    public static void main(String[] args) {

        SparkConf sparkConf = new SparkConf().setAppName("Newborns");

        try {
            sparkConf.get("spark.master");
        } catch (NoSuchElementException e) {
            sparkConf.setMaster("local");
        }

        JavaSparkContext sc = new JavaSparkContext(sparkConf);
        JavaRDD<String> records = sc.textFile(args[0]);
        JavaRDD<DeathRecord> rdd = records.filter(d -> DeathRecord.isParsable(d)).map(d -> new DeathRecord(d));

        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter("/home/rovkp/results.txt"));
        } catch (IOException e) {
            e.printStackTrace();
        }

//        1. Koliko je ženskih osoba umrlo u lipnju kroz čitav period?
//        2. Koji dan u tjednu je umrlo najviše muških osoba starijih od 50 godina?
//        3. Koliko osoba je bilo podvrgnuto obdukciji nakon smrti?
//        4. Kakvo je kretanje broja umrlih muškaraca u dobi između 45 i 65 godina po mjesecima ? Rezultat je (sortirana)
//        lista tipa Pair2 (ključ je redni broj mjeseca, a vrijednost je broj umrlih muškaraca)
//        5. Kakvo je kretanje postotka umrlih oženjenih muškaraca u dobi između 45 i 65 godina po mjesecima?
//                Rezultat je (sortiran) skup tipa Pair2 (ključ je redni broj mjeseca, a vrijednost je postotak).
//        6. Koji je ukupni broj umrlih u nesreći (kod 1) u cjelokupnom periodu?
//        7. Koliki je broj različitih godina starosti umrlih osoba koji se pojavljuju u zapisima?

        // important fields : monthofdeath, sex, age, maritalstatus, dayofweekdeath, mannerdeath, autopsy

        try {
            writer.write("\nZena umrlo u lipnju: ");
            writer.write("\nDan u tjednu sa najvise muskih umrlih starijih od 50: ");
            writer.write("\nBroj osoba na obdukciji: ");
            writer.write("\nKretanje broja umrlih muskih izmedu 45-65 po mjesecima sortirano (mjesec, broj umrlih): ");
            writer.write("\nKretanje postotka umrlih ozenjenih muskih 45-65 po mjesecima (mjesec, postotak): ");
            writer.write("\nUkupno umrlih u nesreci: ");
            writer.write("\nBroj razlicitih godina starosti: ");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
