package hr.fer.rovkp.dz3.zad1;

import hr.fer.rovkp.dz3.JesterParser;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.SimpleAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.FieldType;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.RAMDirectory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by Igor Farszky on 9.5.2017..
 */
public class Main {

    private static RAMDirectory directory = new RAMDirectory();
    private static Analyzer analyzer = new SimpleAnalyzer();

    public static void main(String[] args) throws IOException, ParseException {

        File file = new File("C:\\Users\\Igor Farszky\\Desktop\\jester_items.dat");

        JesterParser jp = new JesterParser(file);

        Map<Integer, String> jesterMap = jp.getDataMap();

        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        IndexWriter writer = new IndexWriter(directory, config);
        for (Map.Entry<Integer, String> entry : jesterMap.entrySet()) {
            addDocument(entry.getKey(), entry.getValue(), writer);
        }
        writer.close();

        float[][] simmatrix = new float[jesterMap.size()][jesterMap.size()];

        int i = 0;
        IndexReader reader = DirectoryReader.open(directory);
        float max = 0;
        for (Map.Entry<Integer, String> entry : jesterMap.entrySet()) {

            TopDocs docs = searchDocument(entry.getValue(), jesterMap.size(), reader);

            if (docs.getMaxScore() > max){
                max = docs.getMaxScore();
            }

            for (ScoreDoc scoreDoc : docs.scoreDocs) {
                simmatrix[entry.getKey() - 1][scoreDoc.doc] = scoreDoc.score;
            }

            i++;

        }

        for(int k=0; k<jesterMap.size(); k++){
            for (int j=0; j<jesterMap.size(); j++){
                simmatrix[k][j] /= max;
            }
        }

        reader.close();

        Map<Float, String> simmap = new TreeMap<>();
        BufferedWriter bufWriter = new BufferedWriter(new FileWriter("C:\\Users\\Igor Farszky\\Desktop\\item_similarity.csv"));
        BufferedWriter bufWriterDups = new BufferedWriter(new FileWriter("C:\\Users\\Igor Farszky\\Desktop\\item_similarity_dups.csv"));
        for (int k=0; k<jesterMap.size(); k++){
            for (int j=0; j<jesterMap.size(); j++){
                if (simmatrix[k][j] != 0) {
                    if (!simmap.containsKey(simmatrix[k][j])) {
                        bufWriter.write((k + 1) + "," + (j + 1) + "," + simmatrix[k][j] + "\n");
                        simmap.put(simmatrix[k][j], k + ":" + j);
                    }else{
                        simmap.replace(simmatrix[k][j],
                                simmap.get(simmatrix[k][j]) + " | " + k + ":" + j);
                    }
                }
            }
        }

        for (Map.Entry<Float, String> entry: simmap.entrySet()){
            bufWriterDups.write(entry.getValue() + "," + entry.getKey() + "\n");
        }

        bufWriter.close();
        bufWriterDups.close();

    }

    private static void addDocument(Integer key, String value, IndexWriter writer) throws IOException {

        Document luceneDoc = new Document();

        FieldType idFieldType = new FieldType();
        idFieldType.setStored(true);
        idFieldType.setTokenized(false);
        idFieldType.setIndexOptions(IndexOptions.NONE);
        Field idField = new Field("id", key.toString(), idFieldType);

        FieldType textFieldType = new FieldType();
        textFieldType.setStored(false);
        textFieldType.setTokenized(true);
        textFieldType.setIndexOptions(IndexOptions.DOCS);
        Field textField = new Field("text", value.toString(), textFieldType);

        luceneDoc.add(idField);
        luceneDoc.add(textField);

        writer.addDocument(luceneDoc);
        writer.commit();

    }

    private static TopDocs searchDocument(String text, int ntop, IndexReader reader) throws IOException, ParseException {

        IndexSearcher searcher = new IndexSearcher(reader);
        Query query = new QueryParser("text", analyzer).parse(QueryParser.escape(text));
        TopDocs topDocs = searcher.search(query, ntop);

        return topDocs;

    }

}
